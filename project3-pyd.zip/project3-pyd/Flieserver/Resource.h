﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 Flieserver.rc 使用
//
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_FlieserverTYPE              130
#define IDD_DISPLAYVIEW                 312
#define IDC_PORT                        1001
#define IDC_LISTEN                      1002
#define IDC_STOP                        1003
#define IDC_BUTTON3                     1010
#define IDC_USEROL                      1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        318
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
